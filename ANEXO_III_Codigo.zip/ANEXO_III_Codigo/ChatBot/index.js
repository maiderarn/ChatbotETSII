// Para crear nuestro servidor web 
const express = require('express')
const app = express()
const {WebhookClient} = require('dialogflow-fulfillment'); // Librería de DialogFlow
const {Suggestion, Image, Card, Payload} = require('dialogflow-fulfillment');
const { dialogflow } = require('actions-on-google');
const mongoose = require('mongoose'); // Importar librería para mongoDB (base de datos)
const Horarios = require('../ChatBot/Models/Horarios');
const Examenes = require('../ChatBot/Models/Examenes');
const { find, exists } = require('../ChatBot/Models/ubicacion');
const contactodepartamentos = require('../ChatBot/Models/contactodepartamento');
const ubicacion = require('../ChatBot/Models/ubicacion');
const Cita = require('../ChatBot/Models/Cita');
const { stringify } = require('actions-on-google/dist/common');
const { json } = require('express');

//Horarios.find({},(err, res)=>{
  //  if(res) return console.log(res)
//});

// Conectar con MongoDB
 mongoose.connect('mongodb+srv://chatbot_upm:chatbot_upm@dialogflowcluster.vt5weyw.mongodb.net/ChatBotUPM?retryWrites=true&w=majority',(err,res) => { 

    if(err) return console.log("Error en la base de datos: ", err);
    console.log("Base de datos online conectada");
 });


app.get('/', function (req, res) {
  res.send('ChatBot UPM :)') //Mensaje que aparecerá al entrar en el localhost:....
})


app.post('/webhook',express.json(), function (req, res) { // express.json ya que los mensajes enviados son en json 
  console.log('Parámetros recibidos');
    const agent = new WebhookClient({ request:req, response:res });
    //console.log('Dialogflow Request headers: ' + JSON.stringify(req.headers));
    //console.log('Dialogflow Request body: ' + JSON.stringify(req.body));

   // Funciones para cada intents:
    function welcome(agent) {
      agent.add(`Welcome to my agent!`);
    }
    
    function fallback(agent) {
      agent.add(`I didn't understand`);
      agent.add(`I'm sorry, can you try again?`);
    }



   async function ConsultarHorarios(agent) {

      // Se almacenan los parámetros necesarios para realizar la consulta:
      let master = agent.parameters.Master;
      let day = agent.parameters.DiasDeLaSemana;
      let cuatri = agent.parameters.cuatrimestre;

      if (day != 't'){
      switch (day) {

        case 'l':
           d = "lunes";
        break;

        case "m":
           d = "martes";
        break;

        case "x":
           d = "miércoles";
        break;

        case "j":
           d = "jueves";
        break;

        case "v":
           d = "viernes";
        break;

        
      }

  

      let res = await Horarios.find({master : master, dia : day, cuatrimestre : cuatri, asignatura:{$ne:""}}) //Consulta a la base de datos
               .sort('hora_ini') // Se ordenan por hora
               console.log((res.length))

               //Se elabora el mensaje en función del día consultado y de las clases.
              
              if (res.length == 0){

                mensaje = "Los "+d+" no hay clases para dicho máster.";
              
              }else{

                mensaje = "Es horario solicitado para el " + d + " es la siguiente: ";

                for (var i = 0; i < res.length; i++) {
                  
                  mensaje = mensaje + "\n\nDe "+res[i].hora_ini+" a "+res[i].hora_fin+" --> "+res[i].asignatura;
                }
              }
            }
            else {

              mensaje = "Es horario solicitado es el siguiente: ";

              let l = await Horarios.find({master : master, dia : "l", cuatrimestre : cuatri}) //Consulta a la base de datos
               .sort('hora_ini') // Se ordenan por hora

               if (l.length == 0){

                mensaje = mensaje + "\n\n LUNES sin docencia";
              
              }else{

                mensaje = mensaje + "\n\nLUNES:"
                for (var i = 0; i < l.length; i++) {
                  
                  mensaje = mensaje + "\nDe "+l[i].hora_ini+" a "+l[i].hora_fin+" --> "+l[i].asignatura;
                }}

                let m = await Horarios.find({master : master, dia : "m", cuatrimestre : cuatri}) //Consulta a la base de datos
               .sort('hora_ini') // Se ordenan por hora

               if (m.length == 0){

                mensaje = mensaje + "\n\n MARTES sin docencia";
              
              }else{
                mensaje = mensaje + "\n\nMARTES:"
                for (var i = 0; i < m.length; i++) {
                  
                  mensaje = mensaje + "\nDe "+m[i].hora_ini+" a "+m[i].hora_fin+" --> "+m[i].asignatura;
                }}

                let x = await Horarios.find({master : master, dia : "x", cuatrimestre : cuatri}) //Consulta a la base de datos
               .sort('hora_ini') // Se ordenan por hora

               if (x.length == 0){

                mensaje = mensaje + "\n\n MIÉRCOLES sin docencia";
              
              }else{
                mensaje = mensaje + "\n\nMIÉRCOLES:"
                for (var i = 0; i < x.length; i++) {
                  
                  mensaje = mensaje + "\nDe "+x[i].hora_ini+" a "+x[i].hora_fin+" --> "+x[i].asignatura;
                }}

                let j = await Horarios.find({master : master, dia : "j", cuatrimestre : cuatri}) //Consulta a la base de datos
               .sort('hora_ini') // Se ordenan por hora

               if (j.length == 0){

                mensaje = mensaje + "\n\n JUEVES sin docencia";
              
              }else{
                mensaje = mensaje + "\n\nJUEVES:"
                for (var i = 0; i < j.length; i++) {
                  
                  mensaje = mensaje + "\nDe "+j[i].hora_ini+" a "+j[i].hora_fin+" --> "+j[i].asignatura;
                }}

                let v = await Horarios.find({master : master, dia : "v", cuatrimestre : cuatri}) //Consulta a la base de datos
               .sort('hora_ini') // Se ordenan por hora

               if (v.length == 0){

                mensaje = mensaje + "\n\n VIERNES sin docencia";
              
              }else{
                mensaje = mensaje + "\n\nVIERNES:"
                for (var i = 0; i < v.length; i++) {
                  
                  mensaje = mensaje + "\nDe "+v[i].hora_ini+" a "+v[i].hora_fin+" --> "+v[i].asignatura;
                }}
              


            }
          
              return agent.add(mensaje);

      
             }




  async function ConsultarExamenes(agent) {

  // Se almacenan los parámetros necesarios para realizar la consulta:
  let master = agent.parameters.Master;
  let conv = agent.parameters.Convocatoria;

  let res = await Examenes.find({master : master, convocatoria : conv}) //Consulta a la base de datos
  .sort('fecha') 
  console.log((res.length))
  mensaje = "Según la información registrada actualmente en el POD de la UPM:";
  for (var i = 0; i < res.length; i++) {
                  
    mensaje = mensaje +"\n\n"+res[i].asignatura+" el "+res[i].fecha+" a las "+res[i].hora + ", en el aula "+res[i].aula;
  }
      return agent.add(mensaje);


}

async function ConsultarDepartamentos(agent) {

  // Se almacenan los parámetros necesarios para realizar la consulta:
  let departamentos = agent.parameters.departamento;
  let cargodepartamento = agent.parameters.cargodepartamento;

let rescontacto =await contactodepartamentos.find({Departamento : departamentos, Cargo : cargodepartamento}); //Consulta a la base de datos
//console.log(rescontacto[0].Nombre)
return  agent.add('El ' +rescontacto[0].Cargo+ ' del departamento de '+rescontacto[0].Departamento+ ' es ' +rescontacto[0].Nombre+ ' y su mail es ' +rescontacto[0].Mail);

   }

 async function ConsultarUbicacion(agent) {
    let respuesta=agent.parameters.comollegarodireccion;
    if (respuesta == 'Ubicación'){

      mensaje = "\nLa dirección de la Escuela Técnica Superior de Ingenieros Industriales. José Gutiérrez Abascal 2, 28006 Madrid y sus coordenadas  40.44, -3.69";
    
    }else{
      mensaje = "\nSi desea llegar en renfe la estación más cercana será Nuevos Ministerios.\nSi desea llegar en metro las estaciones más cercanas serán Nuevos ministerios, Gregorio Marañón y República de Argentina.\n Si desea llegar en autobús deberá montarse en  Línea 7, Línea 12, Línea 14, Línea 40, Línea 45, Línea 147"
    }
    console.log(mensaje)
  return agent.add(mensaje);
  
  
        }

    async function ConsultarMailProfesor(agent) {

          // Se almacenan los parámetros necesarios para realizar la consulta:
        let nombre = agent.parameters.nombreprofesor;   
        let resn =await contactodepartamentos.find({Nombre : nombre}); //Consulta a la base de datos
        console.log(resn)
        return  agent.add( resn[0].Nombre+ ' pertenece al departamento de '+resn[0].Departamento+ ' y su mail es ' +resn[0].Mail);
           }






    async function PedirCita(agent) {
    
    
    let fecha = new Date(agent.parameters.fecha)
    const fechaCita = fecha.toLocaleDateString('es-ES');
    const diaCita = fecha.getDay();
    let hora = new Date(agent.parameters.hora);
    const horaCita = hora.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const hCita = hora.getHours()
    let nombre = agent.parameters.NombreApellido;
    let motivo = agent.parameters.Motivo;
    let correct = true;
    console.log("Hora: "+horaCita+  "   Fecha: "+ fechaCita);

//  Primero mira en la base de datos que haya hueco
    let l = await Cita.find({fecha : fechaCita}) 
               .sort('hora') // Se ordenan por las horas de las citas registradas ese dia
        for (var i = 0; i < l.length; i++) {
          
          if ((l[i].hora == horaCita))
          {
            correct = false;
            mensaje = ("La hora seleccionada no está disponible, pruebe con otra hora."); 

            
          }
        }
        if(hCita > 20 || hCita <9)
        {
          correct = false;
          mensaje = ("La hora seleccionada se encuentra fuera del horario de apertura. La Secretaria del centro abre de 9:00 a 20:00."); 

        }
        if(diaCita == 6 || diaCita == 7)
        {
            correct = false;
            mensaje = ("El centro se encuntra cerrado el día solicitado. Recuerde que la Secretaria del centro abre de lunes a viernes."); 

        }
        if((correct == true))
        {
          let Citas = new Cita({

            hora : horaCita,
            fecha : fechaCita,
            motivo : motivo,
            nombre : nombre,
            });
            Citas.save((err,res)=>{
                if (err) return console.log(err);
                console.log("Nueva Cita almacenada", res)
            })

            mensaje = ("Cita registrada.\n\nPara el: " +fechaCita+"\nA las: "+horaCita+"\nA nombre de: "+nombre)

        }

    return agent.add(mensaje)
        }



    let intentMap = new Map();
    intentMap.set('Default Welcome Intent', welcome); // Nombre de los intents
    intentMap.set('Default Fallback Intent', fallback);
    intentMap.set('ConsultarExamenes', ConsultarExamenes); 
    intentMap.set('ConsultarHorarios', ConsultarHorarios);
    intentMap.set('ConsultarDepartamentos', ConsultarDepartamentos);
    intentMap.set('ConsultarMailProfesor', ConsultarMailProfesor);
    intentMap.set('PedirCita', PedirCita);
    intentMap.set('ConsultarUbicacion', ConsultarUbicacion); //Creada por nosotros (Nombre del intents, función asociada)
    // intentMap.set('your intent name here', yourFunctionHandler);
    // intentMap.set('your intent name here', googleAssistantHandler);s
    agent.handleRequest(intentMap);
  });
  
// El puerto utilizado es el 3000
app.listen(3000, ()=> { 
    console.log("Se está ejecutando el servidor en el puerto "+ 3000);
});



// URL generada por ngrok: https://700e-87-218-51-168.ngrok.io

