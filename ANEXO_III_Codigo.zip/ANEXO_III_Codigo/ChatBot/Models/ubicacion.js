// Definir modelos de colecciones

const { DateTime } = require('actions-on-google');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const ubicacionSchema = new Schema({
  coordenadas : String,
  direccion : String,
  renfe : String,
  autobus : String,
  metro : String,
  busca : String,
},
{timestamps:true}//Para saber la fecha de acceso
);

module.exports = mongoose.model("ubicacion",ubicacionSchema);