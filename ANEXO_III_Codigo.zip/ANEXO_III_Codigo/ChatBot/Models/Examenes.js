// Definir modelos de colecciones

const { DateTime } = require('actions-on-google');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const ExamenesSchema = new Schema({
  master : String,
  asignatura: String,
  fecha : String,
  hora : String,
  aula: String,
  convocatoria : Number,
},
{timestamps:true}//Para saber la fecha de acceso
);

module.exports = mongoose.model("Examenes",ExamenesSchema);