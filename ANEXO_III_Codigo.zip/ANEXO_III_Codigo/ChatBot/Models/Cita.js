// Definir modelos de colecciones

const { DateTime } = require('actions-on-google');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const CitaSchema = new Schema({
  hora : String,
  fecha : String,
  motivo : String,
  nombre : String,
},
{timestamps:true}//Para saber la fecha de acceso
);

module.exports = mongoose.model("Cita",CitaSchema);