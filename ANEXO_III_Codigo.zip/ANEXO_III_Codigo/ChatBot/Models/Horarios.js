// Definir modelos de colecciones

const { DateTime } = require('actions-on-google');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const HorariosSchema = new Schema({
  master : String,
  dia : String,
  hora_ini : String,
  hora_fin : String, 
  asignatura : String,
  cuatrimestre : Number,
},
{timestamps:true}//Para saber la fecha de acceso
);

module.exports = mongoose.model("Horarios",HorariosSchema);