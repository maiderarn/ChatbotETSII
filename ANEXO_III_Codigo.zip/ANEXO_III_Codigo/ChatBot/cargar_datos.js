
//------------------------------------------------------------------------------------------------
// Descomentar solo cuando se vayan a añadir datos para no duplicar ficheros en la base de datos
//------------------------------------------------------------------------------------------------

// Programa que permite cargar datos en la base de datos

const mongoose = require('mongoose'); // Importar librería para mongoDB (base de datos)
const Horarios = require('../ChatBot/Models/Horarios');
const Examenes = require('../ChatBot/Models/Examenes');
const { find, exists } = require('../ChatBot/Models/Horarios');

// Conectar con MongoDB
mongoose.connect('mongodb+srv://chatbot_upm:chatbot_upm@dialogflowcluster.vt5weyw.mongodb.net/ChatBotUPM?retryWrites=true&w=majority',(err,res) => { 

    if(err) return console.log("Error en la base de datos: ", err);
    console.log("Base de datos online conectada");
    
 });
/*
Dias = ["l","l","l","m","m","x","x","j","j","j"];

Horas_inicio = ["12:30","15:30","17:30","15:30","17:30","15:30","17:30","12:30","15:30","17:30"];

Horas_fin = ["14:30","17:30","19:30","17:30","21:30","17:30","19:30","14:30","17:30","19:30"];

Asignatura = ["Separation and Transmutation of Radioactive Wastes","Seguridad Energética","Nuclear Fusion","Reliability and Risk Analysis","Gestión de Residuos Radiactivos",

            "Neutrónica","Nuclear Safety: Nuclear Accident Analysis","Tecnologías Avanzadas en Reactores Nucleares",
        
                "Nuclear Reactor Design", "Radiological Environmental Impact"];

rellenar_Horario("MUCTN",2,Dias,Horas_inicio,Horas_fin,Asignatura)


function rellenar_Horario(nombre,c,d,hi,hf,a) {
    for (let index = 0; index < Asignatura.length ; index++) {
        
        let Horario = new Horarios({

        master : nombre,
        dia : d[index],
        hora_ini : hi[index],
        hora_fin : hf[index],  
        asignatura : a[index],
        cuatrimestre: c,
        });
        Horario.save((err,res)=>{
            if (err) return console.log(err);
            console.log("Nuevo Horario almacenado", res)
        })
    }
    }
*/



rellenar_Examenes("MUAR",
                "Técnicas Avanzadas de Visión por Computador",
                "12 de julio de 2023",
                "15:30",
                "???",
                3)


function rellenar_Examenes(nombre,asig,f,h,aula,c) {
        
        let Examen = new Examenes({

        master : nombre,
        asignatura : asig,
        fecha : f,
        hora : h,  
        aula : aula,
        convocatoria: c,
        });
        Examen.save((err,res)=>{
            if (err) return console.log(err);
            console.log("Nuevo Examen almacenado", res)
        })
   
    }
